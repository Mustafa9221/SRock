class TabModel {
  final String id;
  final String title;
  final String description;

  TabModel({required this.id, required this.title, required this.description});

  factory TabModel.fromMap(Map<String, dynamic> data, String documentId) {
    return TabModel(
      id: documentId,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
    );
  }
}
