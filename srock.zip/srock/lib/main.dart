import 'package:flutter/material.dart';
import 'package:music_studio_app/services/firestore_service.dart';
import 'package:music_studio_app/services/locator.dart';
import 'package:music_studio_app/utils/constants.dart';
import 'package:music_studio_app/viewmodels/bottom_nav_provider.dart';
import 'package:music_studio_app/views/nav_bar_screens/new_page.dart';
import 'package:music_studio_app/widgets/bottom_nav_bar.dart';
import 'package:provider/provider.dart';
import 'views/home_screen/home_screen.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';


Future main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
  );
  final data = await FirestoreServiceImpl().getTabs();
  print("\x1B[31m $data");
  setupLocator();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => BottomNavProvider()),
      ],
    child: const MyApp(), 
    )
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(399, 844), 
      builder: (context, child) {
        return MaterialApp(
      title: 'Music Services',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF18171C),
      ),
      home: const MainScreen(),
        );
      }
    );
  }
}



class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: 0);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  final List<Widget> _pages = [
    const HomeScreen(),
    const NewPage("News"),
    const NewPage("TrackBox"),
    const NewPage("Projects"),
  ];

  @override
  Widget build(BuildContext context) {
    final navProvider = Provider.of<BottomNavProvider>(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: PageView(
        controller: _pageController,
        onPageChanged: (index) {
          navProvider.updateIndex(index);
        },
        children: _pages,
      ),
      bottomNavigationBar: BottomNavBar(
        selectedIndex: navProvider.selectedIndex,
        onTap: (index) {
          _pageController.animateToPage(
            index,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeInOut, // smooth shifting right-to-left
          );
          navProvider.updateIndex(index);
        },
      ),
    );
  }
}
