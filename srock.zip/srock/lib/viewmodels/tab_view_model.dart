import 'package:flutter/foundation.dart';
import 'package:music_studio_app/services/firestore_service.dart';
import 'package:music_studio_app/services/locator.dart';
import '../models/tab_model.dart';

class TabViewModel extends ChangeNotifier {
  final FirestoreService _firestoreService = locator<FirestoreService>();

  List<TabModel> _tabs = [];
  List<TabModel> get tabs => _tabs;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Future<void> fetchTabs() async {
    _isLoading = true;
    notifyListeners();

    try {
      _tabs = await _firestoreService.getTabs();
    } catch (e) {
      if (kDebugMode) print("Error fetching tabs: $e");
    }

    _isLoading = false;
    notifyListeners();
  }
}
