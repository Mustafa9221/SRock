import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppStyles {
  static final colors = _Colors();
  static final textStyles = _TextStyles();
  static final spacing = _Spacing();
  static final radius = _Radius();
  static final shadows = _Shadows();
}

class _Colors {
  final background = const Color(0xFF18171C);
  final primary = const Color(0xFFA90140);
  final primaryDark = const Color(0xFF550120);
  final searchBackground = const Color(0xFF2F2F39);
  final borderColor = const Color(0xFF2C2D31);
  final textGrey = const Color(0xFF61616B);
  final white = Colors.white;
  final black = Colors.black;
}

class _TextStyles {
  final heading1 = TextStyle(
    fontFamily: 'Lobster',
    fontSize: 40.sp,
    fontWeight: FontWeight.w400,
    color: Colors.white,
  );

  final heading2 = TextStyle(
    fontFamily: 'Syne',
    fontSize: 16.sp,
    fontWeight: FontWeight.w700,
    color: Colors.white,
  );

  final body1 = TextStyle(
    fontFamily: 'Syne',
    fontSize: 14.sp,
    fontWeight: FontWeight.w400,
    color: Colors.white,
  );

  final body2 = TextStyle(
    fontFamily: 'Syne',
    fontSize: 13.sp,
    fontWeight: FontWeight.w400,
    color: Colors.white,
  );

  final caption = TextStyle(
    fontFamily: 'Syne',
    fontSize: 11.sp,
    fontWeight: FontWeight.w400,
    color: Colors.white,
  );
}

class _Spacing {
  final double xs = 4.w;
  final double sm = 8.w;
  final double md = 16.w;
  final double lg = 24.w;
  final double xl = 32.w;

  final double buttonHorizontal = 13.w;
  final double buttonVertical = 7.h;

  final double cardPadding = 10.w;
  final double sectionPadding = 20.w;
}

class _Radius {
  final double button = 50.r;
  final double card = 15.r;
  final double searchBar = 10.r;
}

class _Shadows {
  final card = [
    BoxShadow(
      color: Colors.black.withOpacity(0.1),
      blurRadius: 10, // not scaled — visual effect
      offset: Offset(0, 2), // not scaled — visual effect
    ),
  ];
}
