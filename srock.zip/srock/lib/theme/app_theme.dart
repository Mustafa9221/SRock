import 'package:flutter/material.dart';
import 'package:music_studio_app/theme/app_style.dart';

class AppTheme {
  static ThemeData get theme {
    return ThemeData(
      scaffoldBackgroundColor: AppStyles.colors.background,
      primaryColor: AppStyles.colors.primary,
      textTheme: TextTheme(
        displayLarge: AppStyles.textStyles.heading1,
        displayMedium: AppStyles.textStyles.heading2,
        bodyLarge: AppStyles.textStyles.body1,
        bodyMedium: AppStyles.textStyles.body2,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppStyles.radius.button),
          ),
          padding: EdgeInsets.symmetric(
            horizontal: AppStyles.spacing.buttonHorizontal,
            vertical: AppStyles.spacing.buttonVertical,
          ),
        ),
      ),
    );
  }
}
