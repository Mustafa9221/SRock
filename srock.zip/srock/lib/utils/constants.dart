import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppColors {
  static const background = Color(0xFF18171C);
  static const primary = Color(0xFFA90140);
  static const primaryDark = Color(0xFF550120);
  static const searchBackground = Color(0xFF2F2F39);
  static const borderColor = Color(0xFF2C2D31);
  static const textGrey = Color(0xFF61616B);
}

class AppTextStyles {
  static final title = TextStyle(
    color: Colors.white,
    fontSize: 17.sp,
    fontFamily: 'SF Pro',
    fontWeight: FontWeight.w600,
  );

  static final body = TextStyle(
    color: Colors.white,
    fontSize: 14.sp,
    fontFamily: 'Syne',
    fontWeight: FontWeight.w400,
  );

  static final caption = TextStyle(
    color: Colors.white,
    fontSize: 11.sp,
    fontFamily: 'Syne',
    fontWeight: FontWeight.w400,
  );
}
