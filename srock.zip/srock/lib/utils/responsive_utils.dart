import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ResponsiveUtils {
  static double screenWidth() => 1.sw;  // ScreenUtil extension for width
  static double screenHeight() => 1.sh; // ScreenUtil extension for height

  static bool isMobile() => screenWidth() < 600.w;

  // Return the mobile value regardless (you can extend logic later)
  static double getResponsiveValue({
    required double mobile,
  }) {
    return mobile;
  }

  static EdgeInsets getResponsivePadding({
    required EdgeInsets mobile,
  }) {
    return mobile;
  }
}

extension ResponsiveContext on BuildContext {
  double get screenWidth => 1.sw;
  double get screenHeight => 1.sh;
  bool get isMobile => screenWidth < 600.w;
}

