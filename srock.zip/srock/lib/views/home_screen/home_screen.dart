import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:music_studio_app/utils/constants.dart';
import 'package:music_studio_app/viewmodels/tab_view_model.dart';
import 'package:music_studio_app/widgets/bottom_nav_bar.dart';
import 'package:music_studio_app/widgets/hero_section.dart';
import 'package:music_studio_app/widgets/search_bar.dart';
import 'package:music_studio_app/widgets/service_card.dart';
import 'package:provider/provider.dart';


class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => TabViewModel()..fetchTabs(),
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: Column(
          children: [
            // const StatusBar(),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [AppColors.primary, AppColors.primaryDark],
                        ),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(15.r),
                          bottomRight: Radius.circular(15.r),
                        ),
                      ),
                      child: Column(
                        children: [
                          SizedBox(height: 25.h,),
                          const CustomSearchBar(),
                          const HeroSection(),
                        ],
                      ),
                    ),
                    SizedBox(height: 24.h),
                    Text(
                      'Hire hand-picked Pros for popular music services',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15.sp,
                        fontFamily: 'Syne',
                      ),
                    ),
                    SizedBox(height: 24.h),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 30.w),
                      child: Consumer<TabViewModel>(
                        builder: (context, viewModel, _){
                          if (viewModel.isLoading) {
                            return const Center(child: CircularProgressIndicator());
                          }

                          if (viewModel.tabs.isEmpty) {
                            return const Center(child: Text("No tabs found."));
                          }
                          viewModel.tabs.sort((a, b) => a.id.compareTo(b.id));
                          return Column(
                            children: [
                              ServiceCard(
                                id: 0,
                                title: viewModel.tabs[0].title,
                                subtitle: viewModel.tabs[0].description,
                                iconColor: Color(0xFFFF7575),
                                backgroundImage:
                                    'musicbg.png',
                              ),
                              SizedBox(height: 11),
                              ServiceCard(
                                id: 1,
                                title: viewModel.tabs[1].title,
                                subtitle: viewModel.tabs[1].description,
                                iconColor: Color(0xFF179F98),
                                backgroundImage:
                                    'mixingbg.png',
                              ),
                              SizedBox(height: 11),
                              ServiceCard(
                                id: 2,
                                title: viewModel.tabs[2].title,
                                subtitle: viewModel.tabs[2].description,
                                iconColor: Color(0xFFCCBE27),
                                backgroundImage:
                                    'lyricsbg.png',
                              ),
                              SizedBox(height: 11),
                              ServiceCard(
                                id: 3,
                                title: viewModel.tabs[3].title,
                                subtitle: viewModel.tabs[3].description,
                                iconColor: Color(0xFFB354DC),
                                backgroundImage:
                                    'vocalsbg.png',
                              ),
                            ],
                          );
                        }
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // BottomNavBar(),
          ],
        ),
      ),
    );
  }
}
