import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:music_studio_app/theme/app_style.dart';

class TabPage extends StatelessWidget {
  final title;
  const TabPage(this.title);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(""),
      backgroundColor: Colors.transparent,),
      body: Center(
         child: Text(
                  "You Tapped on : $title",
                  style: AppStyles.textStyles.heading1.copyWith(fontSize: 25),
                ),
      ),
    );
  }
}