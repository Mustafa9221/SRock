import 'package:flutter/material.dart';
import 'package:music_studio_app/utils/constants.dart';

class StatusBar extends StatelessWidget {
  const StatusBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.primary,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              // Network Icons
              CustomPaint(
                size: const Size(18, 12),
                painter: NetworkIconPainter(),
              ),
              const SizedBox(width: 6),
              CustomPaint(
                size: const Size(15, 12),
                painter: WifiIconPainter(),
              ),
              const SizedBox(width: 6),
              CustomPaint(
                size: const Size(25, 12),
                painter: BatteryIconPainter(),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class NetworkIconPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..strokeWidth = 8
      ..style = PaintingStyle.stroke;

    // Implementation of network signal icon
    // Add the actual implementation here
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class WifiIconPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..strokeWidth = 8
      ..style = PaintingStyle.stroke;

    // Implementation of wifi icon
    // Add the actual implementation here
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class BatteryIconPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..strokeWidth = 8
      ..style = PaintingStyle.stroke;

    // Implementation of battery icon
    // Add the actual implementation here
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
