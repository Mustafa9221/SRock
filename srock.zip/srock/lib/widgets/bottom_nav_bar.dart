import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BottomNavBar extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onTap;

  const BottomNavBar({
    Key? key,
    required this.selectedIndex,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          decoration: BoxDecoration(
            border: Border(
              top: BorderSide(
                color: const Color(0xFF2C2D31),
                width: 1.w,
              ),
            ),
          ),
          child: Padding(
            padding: EdgeInsets.fromLTRB(34.w, 13.h, 34.w, 4.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _NavItem(
                  assetPath: "assets/icon/home.png",
                  label: 'Home',
                  isSelected: selectedIndex == 0,
                  onTap: () => onTap(0),
                ),
                _NavItem(
                  assetPath: "assets/icon/news.png",
                  label: 'News',
                  isSelected: selectedIndex == 1,
                  onTap: () => onTap(1),
                ),
                _NavItem(
                  assetPath: "assets/icon/Music.png",
                  label: 'TrackBox',
                  isSelected: selectedIndex == 2,
                  onTap: () => onTap(2),
                ),
                _NavItem(
                  assetPath: "assets/icon/project.png",
                  label: 'Projects',
                  isSelected: selectedIndex == 3,
                  onTap: () => onTap(3),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}


class _NavItem extends StatelessWidget {
  final String assetPath;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _NavItem({
    Key? key,
    required this.assetPath,
    required this.label,
    required this.onTap,
    this.isSelected = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final color = isSelected ? Colors.white : const Color(0xFF61616B);

    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            assetPath,
            color: color,
            width: 24.w,
            height: 24.h,
          ),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 11.sp,
              fontFamily: 'Syne',
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }
}
