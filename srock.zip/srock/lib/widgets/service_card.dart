import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:music_studio_app/theme/app_style.dart';
import 'package:music_studio_app/views/tab_screen/tab_screen.dart';

class ServiceCard extends StatelessWidget {
  final String title;
  final int id;
  final String subtitle;
  final Color iconColor;
  final String backgroundImage;

  const ServiceCard({
    Key? key,
    required this.id,
    required this.title,
    required this.subtitle,
    required this.iconColor,
    required this.backgroundImage,
  }) : super(key: key);
  
  getIcon(id){
    switch(id){
      case 0: return "musicicon.png";
      case 1: return "mixingicon.png";
      case 2: return "lyricsicon.png";
      default: return "vocalsicon.png";
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (_) => TabPage(title)));
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppStyles.radius.card.r),
          border: Border.all(color: AppStyles.colors.borderColor),
          boxShadow: AppStyles.shadows.card,
          image: DecorationImage(
            image: AssetImage("assets/images/$backgroundImage"),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.fromLTRB(10.w, 10.h, 0, 10.h),
          child: Row(
            children: [
              Image.asset("assets/images/${getIcon(id)}",),
              SizedBox(width: 10.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15.sp,
                        fontFamily: 'Syne',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13.sp,
                        fontFamily: 'Syne',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
              Image.asset(
                "assets/icon/arrow.png",
                color: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
