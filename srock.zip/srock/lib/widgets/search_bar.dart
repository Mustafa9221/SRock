import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:music_studio_app/utils/constants.dart';

class CustomSearchBar extends StatelessWidget {
  const CustomSearchBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(20.w), // responsive padding
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 11.h),
              decoration: BoxDecoration(
                color: AppColors.searchBackground,
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.search,
                    color: Colors.white.withOpacity(0.6),
                    size: 24.sp, // optional: scale icon size if you want
                  ),
                  SizedBox(width: 10.w),
                  Text(
                    'Search',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 14.sp,
                      fontFamily: 'Syne',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    '"Punjabi Lyrics"',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 14.sp,
                      fontFamily: 'Syne',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Spacer(),
                  Icon(
                    Icons.mic,
                    color: Colors.white.withOpacity(0.6),
                    size: 24.sp, // match search icon size
                  ),
                ],
              ),
            ),
          ),
          SizedBox(width: 12.w),
          Container(
            width: 34.w,
            height: 34.h,
            decoration: BoxDecoration(
              color: const Color(0xFFEADDFF),
              borderRadius: BorderRadius.circular(17.r),
            ),
            child: Center(
              child: Image.asset(
                "assets/icon/person.png",
                color: Colors.deepPurple,
                width: 20, // optional: size the asset for responsiveness
                height: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
