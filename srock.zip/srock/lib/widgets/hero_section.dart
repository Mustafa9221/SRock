import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:music_studio_app/theme/app_style.dart';

class HeroSection extends StatelessWidget {
  const HeroSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 20.h),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          
          Positioned(
            left: -100.w,
            top: 0,
            bottom: 0,
            child: Image.asset(
              "assets/images/disc.png",
              width: 121.w,
              height: 121.h,
              fit: BoxFit.contain,
            ),
          ),

          
          Positioned(
            right: -100.w,
            top: 0,
            bottom: 0,
            child: Image.asset(
              "assets/images/piano.png",
              width: 121.w,
              height: 121.h,
              fit: BoxFit.contain,
            ),
          ),

          // Center content with padding to avoid overlap with images
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 60.w),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Claim your',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontFamily: 'Syne',
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  'Free Demo',
                  style: AppStyles.textStyles.heading1.copyWith(fontSize: 40.sp),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20.h),
                const Text(
                  'for custom Music Production',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontFamily: 'Syne',
                    fontWeight: FontWeight.w400,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20.h),
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50.r),
                    ),
                  ),
                  child: const Text(
                    'Book Now',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 13,
                      fontFamily: 'Syne',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
