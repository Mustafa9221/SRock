import 'package:get_it/get_it.dart';
import 'package:music_studio_app/services/firestore_service.dart';

final locator = GetIt.instance;

void setupLocator() {
  locator.registerLazySingleton<FirestoreService>(() => FirestoreServiceImpl());
}
