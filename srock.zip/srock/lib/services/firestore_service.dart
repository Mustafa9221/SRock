import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/tab_model.dart';

abstract class FirestoreService {
  Future<List<TabModel>> getTabs();
}

class FirestoreServiceImpl implements FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Future<List<TabModel>> getTabs() async {
    final snapshot = await _firestore.collection('Tabs').get();
    return snapshot.docs
        .map((doc) => TabModel.fromMap(doc.data(), doc.id))
        .toList();
  }
}
